package ds.edu.mytriviaapplication;

import java.util.ArrayList;

public class TriviaQuestion {
    String question;
    String correct_answer;
    ArrayList<String> answers_list;

    public TriviaQuestion(String question,
                          String correct_answer,
                          ArrayList<String> answers_list) {
        this.question = question;
        this.correct_answer = correct_answer;
        this.answers_list = answers_list;
    }
}
