package ds.edu.mytriviaapplication;

import android.app.Activity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

// What I need getTrivia to do:
// Open an async thread and pull from hosted codespaces app
// needs or default to: 1 question, category 9,

public class GetTrivia {
    TriviaApp ta = null;
    String username;
    // Some way to store current question
    TriviaQuestion question;
   Gson gson = new GsonBuilder()
            .disableHtmlEscaping()
            .create();

    public GetTrivia(String username) {
        this.username = username;
    }

    public void newQuestion(Activity activity, TriviaApp ta ) {
        this.ta = ta;
        new BackgroundTask(activity).execute();
    }

    private class BackgroundTask {
        private Activity activity; // UI thread
        public BackgroundTask(Activity activity) {this.activity = activity;}

        private void startBackground() {
            new Thread(() -> {
                doInBackground();
                activity.runOnUiThread(this::onPostExecute);
            }).start();
        }

        private void execute() {
            startBackground();
        }

        private void doInBackground() {
            try {
                question = getQuestion();
            } catch (Exception e) {
                System.out.println("No Response!");
            }
        }

        public void onPostExecute() { ta.questionReady(question);}

        private TriviaQuestion getQuestion() throws Exception {
            String url = "https://jubilant-succotash-gx5v45xw5v3w6vv-8080.app.github.dev/getQuestions" +
                    "?questionCount=1" +
                    "&difficulty=easy" +
                    "&type=boolean" +
                    "&user=" + username;
            String triviaString = fetch(url);
            if (triviaString  == null) {
                throw new Exception("No response.");
            }
            JsonArray triviaJSON = gson.fromJson(triviaString, JsonArray.class);
            JsonObject questionJSON = triviaJSON.get(0).getAsJsonObject();
            return gson.fromJson(questionJSON, TriviaQuestion.class);
        }

        /**
         * fetch is sourced from https://github.com/CMU-Heinz-95702/Project-1#sslhandshakeexception.
         * Please refer to this link for documentation and explanation, or contact the original creators.
         *
         * @param searchURL url to fetch
         * @return String representation of API output
         */
        private String fetch(String searchURL){
            try {
                // Create trust manager, which lets you ignore SSLHandshakeExceptions
                createTrustManager("TLSV1.3");
            } catch (KeyManagementException | NoSuchAlgorithmException ex) {
                System.out.println("Shouldn't come here: ");
                ex.printStackTrace();
            }
            StringBuilder response = new StringBuilder();
            try {
                URL url = new URL(searchURL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Read all the text returned by the server
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    response.append(str);
                }
                in.close();
            } catch (IOException e) {
                System.err.println("Something wrong with URL");
                return null;
            }
            return response.toString();
        }

        /**
         * createTrustManager is sourced from https://github.com/CMU-Heinz-95702/Project-1#sslhandshakeexception.
         * Please refer to this link for documentation and explanation, or contact the original creators.
         * @param certType
         * @throws KeyManagementException
         * @throws NoSuchAlgorithmException
         */
        private void createTrustManager(String certType) throws KeyManagementException, NoSuchAlgorithmException {
            /**
             * Annoying SSLHandShakeException. After trying several methods, finally this
             * seemed to work.
             * Taken from: http://www.nakov.com/blog/2009/07/16/disable-certificate-validation-in-java-ssl-connections/
             */
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
            };

            // Install the all-trusting trust manager
            SSLContext sc = SSLContext.getInstance(certType);
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        }
    }
}
