package ds.edu.mytriviaapplication;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.content.Context;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TriviaApp extends AppCompatActivity {

    TriviaApp me = this;

    String current_user;
    int current_streak = 0;

    GetTrivia gt = null;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TriviaApp ma = this;
        LinearLayout login = (LinearLayout)findViewById(R.id.login);
        LinearLayout gameplay = (LinearLayout)findViewById(R.id.gameplay);
        login.setVisibility(VISIBLE);
        gameplay.setVisibility(INVISIBLE);

        Button usernameSubmit = (Button)findViewById(R.id.username_submit);
        usernameSubmit.setOnClickListener( new View.OnClickListener() {
            public void onClick(View viewParam) {
                EditText usernameEdit = (EditText)findViewById(R.id.username);
                String username = usernameEdit.getText().toString();
                if (!username.isEmpty()) {
                    System.out.println("user: " + username);
                    gt = new GetTrivia(username);
                    current_user = username;
                    login.setVisibility(INVISIBLE);
                    gameplay.setVisibility(VISIBLE);
                    // Adapted from StackOverflow - how to hide keyboard when done with username submission
                    View view = ma.getCurrentFocus();
                    if (view != null) {
                        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                }
            }
        });

        TextView timeout = (TextView)findViewById(R.id.timeout);
        Button newQuestionSubmit = (Button)findViewById(R.id.newQuestionSubmit);
        CountDownTimer countDownTimer =  new CountDownTimer(5000, 1000) {
            public void onTick(long millisUntilFinished) {
                timeout.setText(String.valueOf((int)(millisUntilFinished / 1000)));
            }

            public void onFinish() {
                timeout.setVisibility(INVISIBLE);
                newQuestionSubmit.setAlpha(1f);
                newQuestionSubmit.setClickable(true);
            }
        };

        newQuestionSubmit.setOnClickListener( new View.OnClickListener() {
            public void onClick(View viewParam) {
                gt.newQuestion(me, ma); // Async
                timeout.setVisibility(VISIBLE);
                newQuestionSubmit.setAlpha(.5f);
                newQuestionSubmit.setClickable(false);
                countDownTimer.start();

            }
        });

    }

    public void questionReady(TriviaQuestion question) {
        TextView questionText = (TextView)findViewById(R.id.questionText);
        TextView feedback = (TextView)findViewById(R.id.feedback);
        feedback.setText("");


        Button trueButton = (Button)findViewById(R.id.trueButton);
        Button falseButton = (Button)findViewById(R.id.falseButton);
        View.OnClickListener correct = v -> {
            current_streak += 1;
            feedback.setText("Correct!");
            feedback.setVisibility(VISIBLE);
        };
        View.OnClickListener incorrect = v -> {
            current_streak = 0;
            feedback.setText("Incorrect!");
            feedback.setVisibility(VISIBLE);
        };
        if (question != null) {
            // Display question
            questionText.setText(question.question);
            questionText.setVisibility(VISIBLE);
            // Assign listeners to true and false based on question
            if (Boolean.valueOf(question.correct_answer)) {
                trueButton.setOnClickListener(correct);
                falseButton.setOnClickListener(incorrect);
            } else {
                trueButton.setOnClickListener(incorrect);
                falseButton.setOnClickListener(correct);
            }
        } else {
            Toast toast = Toast.makeText(getApplicationContext(),
                    "Error in generating question. Please try again later",
                    Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
