package ds.edu.triviawebapp;

import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.model.Projections;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

@WebServlet(name = "DashboardServlet", value = "/dashboard",
                    loadOnStartup = 1,
                    asyncSupported = true)
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        String connectionString = "mongodb://shayanp:distributed95702@ " +
                "ac-infgmws-shard-00-02.bz30kkv.mongodb.net:27017," +
                "ac-infgmws-shard-00-01.bz30kkv.mongodb.net:27017," +
                "ac-infgmws-shard-00-00.bz30kkv.mongodb.net:27017" +
                "/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        // Create a new client and connect to the server
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            try {
                // Send a ping to confirm a successful connection
                MongoDatabase database = mongoClient.getDatabase("trivia");
                // Adapted from https://www.mongodb.com/docs/drivers/java/sync/current/usage-examples/insertOne/
                MongoCollection<Document> collection = database.getCollection("logs");

                    // Adapted from https://www.mongodb.com/docs/drivers/java/sync/current/usage-examples/find/
                    Bson projectionFields = Projections.fields(
                            Projections.include("timestamp", "username", "category", "difficulty", "type", "question", "answer"),
                            Projections.excludeId());

                request.setAttribute("logIterator", collection.find()
                        .projection(projectionFields).iterator());

                MongoCursor<Document> cursor = collection.find().projection(projectionFields).iterator();
                ArrayList<Document> logs = new ArrayList<>();
                HashMap<String, Integer> bestUsers = new HashMap<>();
                int todayUsage = 0;
                HashSet<String> users = new HashSet<>();
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

                while (cursor.hasNext()) {
                    Document d = cursor.next();
                    logs.add(d);

                    String user = (String) d.get("username");
                    bestUsers.put(user, bestUsers.getOrDefault(user, 0) + 1);
                    users.add(user);
                    Date date = (Date) d.get("timestamp");
                    // Compare today date string with timestamp date string
                    if (df.format(date).equals(df.format(new Date()))) {
                        todayUsage += 1;
                    }
                }
                request.setAttribute("logArraylist", logs);
                request.setAttribute("bestUsers", bestUsers);
                request.setAttribute("todayUsage", todayUsage);
                request.setAttribute("uniqueUserCount", users.size());
//
//                    try (MongoCursor<Document> cursor = collection.find()
//                            .projection(projectionFields).iterator()) {
//                        while (cursor.hasNext()) {
//                            System.out.println(cursor.next().toJson());
//                        }
//                    }

                } catch (MongoException me) {
                    System.err.println("Unable to insert and read due to an error: " + me);
                }



            } catch (MongoException e) {
                e.printStackTrace();
            }
        RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
        view.forward(request, response);
        }
        // Display formatted logs

        // Display 3 analytics
        // - Usage over time - most used days + most used time of day
        // - Top users
        // - Answer distribution T vs F

    }