package ds.edu.triviawebapp;

import com.google.gson.*;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

public class TriviaModel {
    // Trivia Parameters:
    // # questions: INT 1 - 50
    // (optional) Category: INT 9 - 32, based on output of https://opentdb.com/api_category.php
    // (optional) Difficulty: STR "easy", "medium", "hard"
    // (optional) Type: STR "multiple", "boolean"
    // Encoding: "url3986" for interpretation purposes
    //
    List<String> validDifficulties = List.of(new String[]{"easy", "medium", "hard"});
    List<String> validTypes = List.of(new String[]{"multiple", "boolean"});

    Gson gson = new GsonBuilder()
            .disableHtmlEscaping()
//            .excludeFieldsWithoutExposeAnnotation()
            .create();

    Gson packager = new GsonBuilder()
            .disableHtmlEscaping()
            .excludeFieldsWithoutExposeAnnotation()
            .create();

    public JsonArray triviaGet(int questionCount,
                            int category,
                            String difficulty,
                            String type) throws InterruptedException {
        String amountURL;
        String categoryURL = "";
        String difficultyURL = "";
        String typeURL = "";
        String encodeURl = "&encode=url3986";
        amountURL = "amount=" + questionCount;
        if (category >= 9 && category <= 32) {
            categoryURL = "&category=" + category;
        }
        if (validDifficulties.contains(difficulty)) {
            difficultyURL = "&difficulty=" + difficulty;
        }
        if (validTypes.contains(type)) {
            typeURL = "&type=" + type;
        }

        String triviaURL = "https://opentdb.com/api.php?" + amountURL
                                                        + categoryURL
                                                        + difficultyURL
                                                        + typeURL
                                                        + encodeURl;
        String triviaString = fetch(triviaURL, "TLSV1.3");
        if (triviaString == null) {
            try {
                System.out.println(triviaString);
                Thread.sleep(5000);
                triviaString = fetch(triviaURL, "TLSV1.3");
            } catch (InterruptedException e) {
                System.out.println("Should not happen.");
            }
        }
        JsonObject triviaJSON = gson.fromJson(triviaString, JsonObject.class);
        JsonArray triviaJSONArray = triviaJSON.get("results").getAsJsonArray();
        ArrayList<Question> questions = new ArrayList<Question>();
        // Turn json elements into questions and decodes string inputs
        for (JsonElement e : triviaJSONArray) {
            Question q = gson.fromJson(e, Question.class);
            q.decode();
            questions.add(q);
        }
        // Returns JSON array of question object strings?
        return packager.toJsonTree(questions).getAsJsonArray();

//        int questionIndex = 1;
//        // Print out each question, options, and correct answer
//        for (Question q : questions) {
//            System.out.println("Category: " + q.getCategory());
//            System.out.println("Question " + questionIndex + ": " + q.getQuestion());
//            System.out.println("Answers: ");
//            char answerIndex = 'A';
//            for (String answer : q.getAnswers_list()) {
//                System.out.println(answerIndex + ". " + answer);
//                answerIndex += 1;
//            }
//            System.out.println();
//            System.out.println("Correct Answer: " + q.getCorrect_answer());
//            System.out.println("---------");
//            questionIndex += 1;
//        }
    }

    /**
     * fetch is sourced from https://github.com/CMU-Heinz-95702/Project-1#sslhandshakeexception.
     * Please refer to this link for documentation and explanation, or contact the original creators.
     * @param searchURL
     * @param certType
     * @return String representation of API output
     */
    private String fetch(String searchURL, String certType){
        try {
            // Create trust manager, which lets you ignore SSLHandshakeExceptions
            createTrustManager(certType);
        } catch (KeyManagementException ex) {
            System.out.println("Shouldn't come here: ");
            ex.printStackTrace();
        } catch (NoSuchAlgorithmException ex) {
            System.out.println("Shouldn't come here: ");
            ex.printStackTrace();
        }
        StringBuilder response = new StringBuilder();
        try {
            URL url = new URL(searchURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response.append(str);
            }
            in.close();
        } catch (IOException e) {
            System.err.println("Something wrong with URL");
            return null;
        }
        return response.toString();
    }

    /**
     * createTrustManager is sourced from https://github.com/CMU-Heinz-95702/Project-1#sslhandshakeexception.
     * Please refer to this link for documentation and explanation, or contact the original creators.
     * @param certType
     * @throws KeyManagementException
     * @throws NoSuchAlgorithmException
     */
      private void createTrustManager(String certType) throws KeyManagementException, NoSuchAlgorithmException {
        /**
         * Annoying SSLHandShakeException. After trying several methods, finally this
         * seemed to work.
         * Taken from: http://www.nakov.com/blog/2009/07/16/disable-certificate-validation-in-java-ssl-connections/
         */
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance(certType);
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }



}