package ds.edu.triviawebapp;

import com.google.gson.JsonArray;
import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.InsertOneResult;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;

@WebServlet(name = "TriviaServlet", value = "/getQuestions")
public class TriviaServlet extends HttpServlet {
    TriviaModel tm = null;

    public void init() {
        tm = new TriviaModel();
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException {
        int questionCount = Integer.parseInt(request.getParameter("questionCount"));
        int category = 0;
        String catObj = request.getParameter("category");
        if (catObj != null) {
            category = Integer.parseInt(catObj);
        }
        String difficulty = request.getParameter("difficulty");
        String type = request.getParameter("type");
        String username = request.getParameter("user");
        if (questionCount != -1) {
            log("Running triviaGet!");
            JsonArray questionArray = null;
            try {
                questionArray = tm.triviaGet(questionCount,
                                                    category,
                                                    difficulty,
                                                    type);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            String question = "None returned";
            if (questionArray != null) {
                question = questionArray.get(0).getAsJsonObject().get("question").toString();
            }
            String answer = "None returned";
            if (questionArray != null) {
                answer = questionArray.get(0).getAsJsonObject().get("correct_answer").toString();
            }

            PrintWriter out = response.getWriter();
            out.print(questionArray.toString());
            out.close();
            logRequest(username, category, difficulty, type, question, answer);
        }
    }

    private void logRequest(String username,
                            int category,
                            String difficulty,
                            String type,
                            String question,
                            String answer) {
        String connectionString = "mongodb://shayanp:distributed95702@ ac-infgmws-shard-00-02.bz30kkv.mongodb.net:27017," +
                "ac-infgmws-shard-00-01.bz30kkv.mongodb.net:27017," +
                "ac-infgmws-shard-00-00.bz30kkv.mongodb.net:27017" +
                "/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        // Create a new client and connect to the server
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            try {
                // Send a ping to confirm a successful connection
                MongoDatabase database = mongoClient.getDatabase("trivia");
                // Adapted from https://www.mongodb.com/docs/drivers/java/sync/current/usage-examples/insertOne/
                MongoCollection<Document> collection = database.getCollection("logs");
                try {
                    System.out.println(question);
                    System.out.println(category);
                    InsertOneResult result = collection.insertOne(new Document()
                            .append("_id", new ObjectId())
                            .append("timestamp", new Timestamp(System.currentTimeMillis()))
                            .append("username", username)
                            .append("category", category)
                            .append("difficulty", difficulty)
                            .append("type", type)
                            .append("question", question)
                            .append("answer", answer));
                    System.out.println("Success! Inserted document id: " + result.getInsertedId());
                } catch (MongoException me) {
                    System.err.println("Unable to insert and read due to an error: " + me);
                }
            } catch (MongoException e) {
                e.printStackTrace();
            }
        }
    }

    public void destroy() {
    }
}